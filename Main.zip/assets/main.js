$(document).ready(function(){
  $('.lazy').slick({
	  lazyLoad: 'ondemand',
	  slidesToShow: 5,
	  slidesToScroll: 1,
	  centerPadding: '10px'
	});
});